const images = {
    customer: require('../assets/images/customer.jpg'),
    distributer: require('../assets/images/distributer.jpg'),
    shopkeeper: require('../assets/images/shopkeeper.jpg'),
}

export default images
